#!/usr/bin/env python3.7
#
# Copyright (c) 2020 Artec Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the License);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at:
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an AS IS BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
import cv2
import datetime
print(cv2.__version__)
print("Click the image to capture")

ORD_ESCAPE = 0x1b

CLOSE_FLG = False
def mouse_event(event, x, y, flags, param):
    global CLOSE_FLG
    if event == cv2.EVENT_LBUTTONUP:
        CLOSE_FLG = True

cc = cv2.VideoCapture(0)
rr, img = cc.read()
cv2.imshow('Click the image to capture',img)
cv2.waitKey(1)
#cv2.namedWindow('capture', cv2.WINDOW_NORMAL)
cv2.setMouseCallback('Click the image to capture', mouse_event)

home_dir = os.getenv('HOME')

while( cc.isOpened() ):
    rr, img = cc.read()
    cv2.imshow('Click the image to capture',img)
    cv2.waitKey(10)

    prop_val = cv2.getWindowProperty('Click the image to capture', cv2.WND_PROP_ASPECT_RATIO)
    if prop_val < 0:
        break

    if CLOSE_FLG:
        now = datetime.datetime.now()
        filename = home_dir + '/Pictures/capture_' + now.strftime('%Y%m%d_%H%M%S') + '.jpg'
        cv2.imwrite(filename,img)
        CLOSE_FLG = False
        break

cc.release()
cv2.destroyAllWindows()
