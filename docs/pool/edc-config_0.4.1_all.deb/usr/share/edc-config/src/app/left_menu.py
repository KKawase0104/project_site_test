#
# Copyright (c) 2020 Artec Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the License);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at:
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an AS IS BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import tkinter as tk
from const import BW, FONT

class LeftMenu:
    def __init__(self, master=None, is_mouse=None):
        ca_button = tk.Canvas(master, width=82, height=82,
                              relief=tk.RIDGE, bd=BW, bg='white',
                              highlightthickness=0)
        ca_button.create_oval(1, 1, 80, 80, fill='black') # Circle
        ca_button.place(anchor=tk.W, relx=0.07, rely=0.4)

        # f_setting1 Left Menu
        f_set1_l_radio = tk.Frame(master, width=210, height=65,
                                  relief=tk.RIDGE, bd=BW, bg='white')

        self.var = tk.IntVar()
        self.var.set(0)
        rb_m1 = tk.Radiobutton(f_set1_l_radio, value=0, font=FONT,
                               variable=self.var, text=_('Mouse'),
                               bg='white', highlightthickness=0)
        rb_as = tk.Radiobutton(f_set1_l_radio, value=1, font=FONT,
                               variable=self.var, text=_('キーボード矢印キー'),
                               bg='white', highlightthickness=0)
        rb_m1.place(anchor=tk.NW, relx=0.0, rely=0.0)
        rb_as.place(anchor=tk.SW, relx=0.0, rely=1.0)

        f_set1_l_radio.place(anchor=tk.SW, relx=0.02, rely=0.9)
        
        if not(is_mouse):
            self.var.set(1)
        
    def get(self):
        return self.var.get()