#
# Copyright (c) 2020 Artec Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the License);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at:
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an AS IS BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import tkinter as tk
from const import BW, FONT
from touchpen_calibration import TouchPanelCalibration

import logging

class CenterMenu:
    CENTER=(120, 92)
    def __init__(self, master=None):

        self.tp_calib_panel = TouchPanelCalibration(master)

        self.data = {'cb': False, 'dx': 0, 'dy': 0}
        self.var = tk.IntVar()
        # f_setting1 Center Menu
        self.chk = tk.Checkbutton(master, text=_('Touch pannel'),
                                  variable=self.var, font=FONT,
                                  justify='center', bg='white', 
                                  highlightthickness=0)
        self.chk.bind('<ButtonRelease-1>', self.check_changed) # 1 -> left button
        self.chk.place(anchor=tk.CENTER, rely=0.1, relx=0.5)

        CA_W = 240
        CA_H = 180
        CENTERX = CA_W / 2
        CENTERY = CA_H / 2
        DIAMETER = 50
        RADIUS = DIAMETER/2
        self.ca = tk.Canvas(master, width=CA_W, height=CA_H,
                            relief=tk.RIDGE, bd=3, bg='gray')
        self.ca.create_oval(CENTERX-RADIUS, CENTERY-RADIUS, 
                            CENTERX+RADIUS, CENTERY+RADIUS) # Circle
        self.ca.create_line(CENTERX-RADIUS*2, CENTERY, 
                            CENTERX+RADIUS*2, CENTERY) # X axis
        self.ca.create_line(CENTERX, CENTERY-RADIUS*2, 
                            CENTERX, CENTERY+RADIUS*2) # Y axis
        self.ca.create_text(10, 10, font=('', 12), fill='gray', 
                            anchor=tk.NW, tag='text',
                            text=_("Touch the circle's center with\nthe stylus.")) # Circle
        self.ca.bind('<ButtonPress-1>', self.get_cursor_pos) # 1 -> left button
        self.ca.place(anchor=tk.CENTER, relx=0.5, rely=0.5)

    def check_changed(self, event):
        logging.debug(event)
        if (self.var.get() == 1):
            self.ca['bg'] = 'white'
            self.tp_calib_panel.openDialog()
        else:
            self.ca['bg'] = 'gray'

    def get_cursor_pos(self, event):
        self.ca.delete('text')
        if (self.var.get() == 1):
            dx = event.x - CenterMenu.CENTER[0]
            dy = event.y - CenterMenu.CENTER[1]
            self.data['dx'] = dx
            self.data['dy'] = dy
            self.ca.create_text(10, 10, font=('', 12), fill='gray', 
                                anchor=tk.NW, tag='text',
                                text=(_("defference x:{0}, y:{1}").format(dx, dy))) # Circle
            

    def get(self):
        self.data['cb'] = self.var.get()
        return self.data
    
    
    
    