#
# Copyright (c) 2020 Artec Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the License);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at:
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an AS IS BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import tkinter as tk
import subprocess
import statistics
from const import BW, FONT

import logging

class TouchPanelCalibration:
    def __init__(self, master=None):
        self.parent = master
        self.dialog = None
        self.var = tk.IntVar()
        self.data = {'min_x': 0, 'min_y': 0, 'max_x': 0, 'max_y': 0}
        self.result = {'min_x': 0, 'min_y': 0, 'max_x': 0, 'max_y': 0}

        self.width = 1024
        self.height = 600

        self.ca_w = 0
        self.ca_h = 0

        self.click_count = 0
        self.detect_count = 0

        self.xv = []
        self.yv = []

    def openDialog(self, callback):
        self.dialog = tk.Toplevel(self.parent)
        self.dialog.geometry("{0}x{1}+0+0".format(self.width, self.height))
        self.dialog.config(cursor='none')
        self.dialog.overrideredirect(1)
        self.dialog.wait_visibility()
        self.dialog.grab_set()
        self.click_count = 0
        self.detect_count = 0
        self.xv = []
        self.yv = []

        self.cb = callback

        CA_W = 40
        CA_H = CA_W
        LN_W = 5
        self.ca_w = CA_W 
        self.ca_h = CA_W 

        self.ca1 = tk.Canvas(self.dialog, width=CA_W, height=CA_H)
        self.ca1.create_line(0, CA_H/2, CA_W, CA_H/2, width=LN_W) # X axis
        self.ca1.create_line(CA_W/2, 0, CA_W/2, CA_H, width=LN_W) # Y axis
        self.ca1.bind('<ButtonPress-1>', self.get_cursor_pos) # 1 -> left button
        self.ca1.place(x=0, y=0)

        self.message = tk.StringVar()
        self.message.set('''
タッチペン補正方法
・ 画面左上の＋印の中心を数回しっかりタップしてください
・ 計測できたら＋印が消えて、画面右下に＋印が表示されます
・ 画面右下の＋印の中心を数回しっかりタップしてください
・ 計測できたら＋印が消えて、設定ボタンが有効になります
・ 設定ボタンで補正値を保存します。
・ 戻るボタンで補正値を設定せずに最初の画面に戻ります。
''')

        self.label = tk.Label(self.dialog, font=FONT, 
                              textvariable=self.message,
                              justify='left'
                             ).place(anchor=tk.CENTER, 
                                     relx=0.5, rely=0.5)
        btn_frame = tk.Frame(self.dialog)
        self.btn_ok = tk.Button(self.dialog, text=_('OK'), 
                                font=FONT, command=self.ok_pressed
                               )
        self.btn_ok.pack(in_=btn_frame, anchor=tk.S, side=tk.LEFT)
        self.btn_ok.configure(state='disabled')
        tk.Button(self.dialog, text=_('戻る'), 
                  command=self.close_window, font=FONT
                  ).pack(in_=btn_frame, anchor=tk.S, side=tk.LEFT)
        btn_frame.pack(anchor=tk.S, side=tk.BOTTOM)

    def nextDetecting(self, posx, posy, msg):
        logging.debug('2nd')
        self.ca1.place(x=posx, y=posy)
        """
        self.message.set(msg)
        """
        self.click_count = 0
        self.detect_count += 1
        self.xv = []
        self.yv = []

    def stopDetecting(self, msg):
        self.ca1.place_forget()
        self.message.set(msg)
        self.click_count = 0
        self.detect_count = 0
        self.btn_ok.configure(state='active')

    def get_cursor_pos(self, event):
        args = ['i2cdump', '-y', '-r', '0x08-0x0d', '11', '9']
        cp = subprocess.run(args, stdout=subprocess.PIPE)
        str = (cp.stdout).decode('utf-8')
        ltok = str.split('\n')
        ltok = ltok[1].split()
        sx = ltok[2] + ltok[1]
        sy = ltok[4] + ltok[3]
        nx = int(sx, 16)
        ny = int(sy, 16)

        if nx == 0:
            return

        self.xv.append(nx)
        self.yv.append(ny)
        logging.debug("data:{0}, {1}".format(nx, ny))
        if len(self.xv) == 6:
            xpstdev = statistics.pstdev(self.xv)
            ypstdev = statistics.pstdev(self.yv)
            logging.debug("{0}, {1}".format(xpstdev, ypstdev))
            if xpstdev < 10 and ypstdev < 10:
                if self.detect_count == 0:
                    self.data['min_x'] = statistics.mean(self.xv)
                    self.data['min_y'] = statistics.mean(self.yv)
                    text='右下の＋印の中心を数回ゆっくりタップしてください'
                    self.nextDetecting(self.width-self.ca_w, 
                                       self.height-self.ca_h,
                                       text)
                else:
                    self.data['max_x'] = statistics.mean(self.xv)
                    self.data['max_y'] = statistics.mean(self.yv)
                    text='完了しました'
                    self.stopDetecting(text)
            else:
                self.xv = []
                self.yv = []

    def ok_pressed(self):
        self.dialog.grab_release()
        self.dialog.withdraw()
        self.dialog = None

	# Voltage calculation of X min/max
        a = (self.data['max_x'] - self.data['min_x']) / (self.width - self.ca_w)
        b = self.data['min_x'] - a * self.ca_w / 2
        self.result['min_x'] = int(b)
        self.result['max_x'] = int(a * self.width + b)
	# Voltage calculation of Y min/max
        a = (self.data['max_y'] - self.data['min_y']) / (self.height - self.ca_h)
        b = self.data['min_y'] - a * self.ca_h / 2
        self.result['min_y'] = int(b)
        self.result['max_y'] = int(a * self.height + b)

        self.cb(self.result)
        return "break"

    def close_window(self):
        self.dialog.grab_release()
        self.dialog.withdraw()
        self.dialog = None
        self.cb(None)
        return "break"
