#
# Copyright (c) 2020 Artec Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the License);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at:
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an AS IS BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import tkinter as tk
from const import BW, FONT
from touchpen_calibration import TouchPanelCalibration

import logging

class CenterMenu:
    CALIBV=[0, 0, 0, 0]	# MIN_X, MAX_X, MIN_Y, MAX_Y
    def __init__(self, master=None):

        self.tp_calib_panel = TouchPanelCalibration(master)

        self.data = {'changed': False, 'min_x': 0, 'min_y': 0, 'max_x': 0, 'max_y': 0}
        #self.var = tk.IntVar()
        # f_setting1 Center Menu
        #self.chk = tk.Checkbutton(master, text=_('Touch pannel'),
        #                          variable=self.var, font=FONT,
        #                          justify='center', bg='white', 
        #                          highlightthickness=0)
        #self.chk.bind('<ButtonRelease-1>', self.check_changed) # 1 -> left button
        #self.chk.place(anchor=tk.CENTER, rely=0.1, relx=0.5)
        title = tk.Label(master, font=FONT,bg='white', 
                         text=_('Touch pannel'))
        title.place(anchor=tk.CENTER, rely=0.1, relx=0.5)

        CA_W = 240
        CA_H = 180
        self.message = tk.StringVar()
        self.message.set('タッチペン補正をする場合はタップしてください')
        self.frame = tk.Frame(master, width=CA_W, height=CA_H,
                                relief=tk.RIDGE, bd=3)
        #self.original_background = self.frame.cget('background')

        self.label = tk.Label(self.frame, font=('', 12),
                 textvariable=self.message,
                 activebackground='white',
                 wraplength=CA_W-5, justify='left'
                )
        self.label.place(anchor=tk.CENTER, 
                        relx=0.5, rely=0.5)
        #self.label.configure(state='disabled')
        self.frame.pack()

        self.frame.bind('<ButtonPress-1>', self.get_cursor_pos) # 1 -> left button
        self.frame.place(anchor=tk.CENTER, relx=0.5, rely=0.5)



    #def check_changed(self, event):
    #    logging.debug(event)
    #    if (self.var.get() == 1):
    #        self.frame['bg'] = 'white'
    #        self.label.configure(state='active')
    #    else:
    #        self.frame['bg'] = self.original_background
    #        self.label.configure(state='disabled')

    def get_cursor_pos(self, event):
        self.tp_calib_panel.openDialog(self.cb_getV)

    def get(self):
        return self.data
    
    def cb_getV(self, *ret):
        rv = ret[0]
        if rv is None:
            pass
        else:
            self.data['changed'] = True
            self.data['min_x'] = rv['min_x']
            self.data['max_x'] = rv['max_x']
            self.data['min_y'] = rv['min_y']
            self.data['max_y'] = rv['max_y']
            text = '''補正値が保存されています。
変更をする場合はタップしてください。'''
            self.message.set(text)
