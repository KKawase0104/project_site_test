#
# Copyright (c) 2020 Artec Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the License);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at:
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an AS IS BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# For Translation
import bootstrap
bootstrap.init_translation()

import logging

logging.basicConfig(level=logging.DEBUG, format='%(levelname)s: %(message)s')
logging.disable(logging.CRITICAL)

import sys
import os
import tkinter as tk
from tkinter import messagebox as tkMessageBox

from const import *
from left_menu import LeftMenu
from center_menu import CenterMenu
from right_menu import RightMenu

import configtxt

import subprocess

ini_menu = configtxt.get()

logging.debug(ini_menu)

# Run
root = tk.Tk()
root.title(_('Configuration'))
root.geometry('870x360+0+0')

f_setting1 = tk.Frame(root, width=630, height=300, relief=tk.RIDGE, bd=BW, padx=PX, pady=PY)
f_setting3 = tk.Frame(root, width=200, height=300, relief=tk.RIDGE, bd=BW, padx=PX, pady=PY)
f_setting4 = tk.Frame(root, width=630, height=100, relief=tk.RIDGE, bd=BW, padx=PX, pady=PY)

# f_setting1, f_setting3
ca = tk.Canvas(f_setting1, width=630, height=300, relief=tk.RIDGE, bd=BW, highlightthickness=0)
round_rectangle(ca, 5, 5, 620, 290, radius=50, fill="white")
ca.pack()

lm = LeftMenu(f_setting1, ini_menu[0])
cm = CenterMenu(f_setting1)
rm = RightMenu(f_setting1, f_setting3, ini_menu[1:6])

# f_setting4
def close_window():
    root.destroy()
    
def ok_pressed():
    # setting process
    logging.debug(lm.get())
    logging.debug(cm.get())
    logging.debug(rm.get())

    setl = lm.get()
    setc = cm.get()
    setr = rm.get()

    configtxt.set(setl, setc, setr)

    res = tk.messagebox.askquestion('', _('Restart your computer to complete the setup?'))
    if res == 'yes':
        root.destroy()
        subprocess.call('reboot')
    else:
        root.destroy()


tk.Button(f_setting4, text=_('OK'), font=FONT, command=ok_pressed).pack(side=tk.LEFT)
tk.Button(f_setting4, text=_('CANCEL'), command=close_window, font=FONT).pack(side=tk.LEFT)

# layout
f_setting1.grid(column=0, row=1)
f_setting3.grid(column=1, row=1)
f_setting4.grid(column=0, row=4)

root.mainloop()
