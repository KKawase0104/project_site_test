#
# Copyright (c) 2020 Artec Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the License);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at:
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an AS IS BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

#import os
import shutil
import re

#home_dir = os.getenv('HOME')

file_config = '/boot/config.txt'
# file_config = '/home/pi/config.txt'           # Test
file_autostart = '/home/pi/.config/lxsession/LXDE-pi/autostart'
#file_autostart = '/home/pi/autostart'         # Test

pattern_bn = 'dtparam=gpio_north_btn=(.*)\n'
pattern_be = 'dtparam=gpio_east_btn=(.*)\n'
pattern_bw = 'dtparam=gpio_west_btn=(.*)\n'
pattern_bs = 'dtparam=gpio_south_btn=(.*)\n'

def get():
    config_init = []

    # get autostart
    with open(file_autostart) as f:
        s = f.read()
    line = re.search('(.*)/usr/share/edc-config/src/service/read_analogstick.sh\n', s)
    l_mouse_used = (line.group(1) == '#')
    config_init.append(l_mouse_used)
    
    # get config.txt
    with open(file_config) as f:
        s = f.read()
    line = re.search('dtparam=gpio_south_btn=0x110\n', s)
    if not(line == None):
        config_init.append(True)
    else:
        config_init.append(False)
        b = re.search(pattern_bn, s)
        b1 = b.group(1)
        b = re.search(pattern_be, s)
        b2 = b.group(1)
        b = re.search(pattern_bw, s)
        b3 = b.group(1)
        b = re.search(pattern_bs, s)
        b4 = b.group(1)
        config_init.append(b1)
        config_init.append(b2)
        config_init.append(b3)
        config_init.append(b4)

    return config_init

def set(l, c, r):
    # back up
    back_name = file_config + '.bak'
    shutil.copy(file_config, back_name)
    back_name = file_autostart + '.bak'
    shutil.copy(file_autostart, back_name)

    # set config.txt
    with open(file_config) as f:
        s = f.read()

    if c['cb'] == 1:    # center menu
        pass

    ln = 'dtparam=gpio_north_btn=0x112\n'
    le = 'dtparam=gpio_east_btn=0x111\n'
    lw = 'dtparam=gpio_west_btn=0x113\n'
    ls = 'dtparam=gpio_south_btn=0x110\n'
    if r['sel'] == 1:   # right menu
        ln = 'dtparam=gpio_north_btn=' + str(r['b1']) + '\n'
        le = 'dtparam=gpio_east_btn=' + str(r['b2']) + '\n'
        lw = 'dtparam=gpio_west_btn=' + str(r['b3']) + '\n'
        ls = 'dtparam=gpio_south_btn=' + str(r['b4']) + '\n'

    s = re.sub(pattern_bn, ln, s)
    s = re.sub(pattern_be, le, s)
    s = re.sub(pattern_bw, lw, s)
    s = re.sub(pattern_bs, ls, s)

    with open(file_config, mode='w') as f:
        f.write(s)


    # set autostart
    with open(file_autostart) as f:
        s = f.read()

    c_o = re.search('(.*)/usr/share/edc-config/src/service/read_analogstick.sh\n', s)
    c_o = (c_o.group(1) == '#')
    if l == 0 and not(c_o):     # set mouse
        s = re.sub('/usr/share/edc-config/src/service/read_analogstick.sh\n', 
                   '#/usr/share/edc-config/src/service/read_analogstick.sh\n', s)
    if l == 1 and c_o:          # set joystick
        s = re.sub('#/usr/share/edc-config/src/service/read_analogstick.sh\n', 
                   '/usr/share/edc-config/src/service/read_analogstick.sh\n', s)

    with open(file_autostart, mode='w') as f:
        f.write(s)
