import tkinter as tk
import tkinter.ttk as ttk
from tkinter import simpledialog

# window_width = 640
# window_height = 430
# screen_width = root.winfo_screenwidth()
# screen_height = root.winfo_screenheight() - 100
# x_cordinate = int((screen_width/2) - (window_width/2))
# y_cordinate = int((screen_height/2) - (window_height/2))

class InfoDialog(simpledialog.Dialog):
    def __init__(self, master=None, msg=''):
        self.message = tk.StringVar()
        self.message.set(msg)

        w = 300
        h = 250
        mw = master.winfo_width()
        mh = master.winfo_height()
        mx = master.winfo_x()
        my = master.winfo_y()

        bgcolor = 'white smoke'
        self.dialog = tk.Toplevel()
        self.dialog.configure(bg=bgcolor)
        self.dialog.geometry('{}x{}+{}+{}'.\
            format(w, h, int(mx+mw/2-w/2), int(my+mh/2-h/2)))
        self.dialog.overrideredirect(1)
        self.dialog.grab_set()

        #pbval = tk.IntVar(value=3)
        self.label = tk.Label(self.dialog, font=('',14), 
                              textvariable=self.message,
                              justify='left', bg=bgcolor)
        self.pb = ttk.Progressbar(self.dialog, orient=tk.HORIZONTAL, maximum=25,
                             value=0, length=200, mode='indeterminate')
        self.pb.place(anchor=tk.CENTER, relx=0.5, rely=0.3)
        self.label.place(anchor=tk.CENTER, relx=0.5, rely=0.5)

    def start(self):
        self.pb.start()

    def stop(self):
        self.pb.stop()

    def setMessage(self, msg):
        self.message.set(msg)
