#
# Copyright (c) 2020 Artec Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the License);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at:
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an AS IS BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import tkinter as tk
import tkinter.ttk as ttk
from PIL import ImageTk, Image
import logging

from distutils.version import LooseVersion

import locale
import textwrap

import scrollable_frame

Message1 = _('OS version')
Message2 = _('You can use the Update button to update to the latest OS. \
It will take some time to update the OS.')

class FeatureTab(tk.Frame):
    def __init__(self, master=None, info=None):
        super().__init__(master)
        self.master = master
        self.app_info_table = []
        self.os_info = info
        #self.init_status = []

    def get(self):
        logging.debug('FeaTab data')

    def show(self):
        frame = tk.Frame(self.master, relief=tk.FLAT, width=640, height=50)
        label1 = tk.Label(frame, text=Message1, font=('',14))
        # Set Text Frame
        label2 = tk.Label(frame, text=self.os_info, 
                          wraplength=340, justify='left', font=('',10))
        label3 = tk.Label(frame, text=Message2, font=('',14), wraplength=340)
        button = tk.Button(frame, text=_('Upgrade'))

        # label1.place(anchor=tk.W)
        # label2.place(anchor=tk.CENTER)
        # label3.place(anchor=tk.W)
        # button.place(anchor=tk.CENTER)

        label1.pack(padx=10, pady=5)#, anchor=tk.W)
        label2.pack(padx=10, pady=5)#, anchor=tk.CENTER)
        label3.pack(padx=10, pady=5)#, anchor=tk.W)
        button.pack(padx=10, pady=5)#, anchor=tk.CENTER)

        frame.pack()

        """
        #-------------------
        # header
        header = tk.Frame(self.master, relief=tk.FLAT, width=640, height=50)
        header_text = tk.Frame(header, bd=10, width=400, height=50)
        header_upde = tk.Frame(header, bd=10, width=240, height=50)

        tk.Label(header_text, text=_('Feature'),font=('',14))\
                              .place(anchor=tk.W, rely=0.5)
        tk.Label(header_upde, text=_('Update'),font=('',14))\
                              .place(anchor=tk.CENTER, relx=0.5, rely=0.5)
    
        header_text.pack(side=tk.LEFT, anchor=tk.W)
        header_upde.pack(side=tk.LEFT, anchor=tk.CENTER)
        #-------------------

        #-------------------
        # body
        body = scrollable_frame.ScrollableFrame(self.master, bar_x=False, width=640, height=300)

        fea = FeatureInfoFrame(body.scrollable_frame,
                self.os_info[0], self.os_info[1])
        fea.pack()
        self.app_info_table.append(fea)

        header.pack()
        body.pack()
        """
"""
class FeatureInfoFrame(tk.Frame):
    def __init__(self, parent, name, comment):
        super().__init__(parent, relief=tk.FLAT, width=640, height=100)

        text_frame = tk.Frame(self, bd=10, width=400, height=100)
        upda_frame = tk.Frame(self, bd=10, width=240, height=100)

        # Set Text Frame
        tk.Label(text_frame, text=name+'\n'+comment, wraplength=340,
                 justify='left', font=('',10)).place(anchor='nw')

        # Set Update Frame
        # create a checkbutton to update
        self.update_req = tk.BooleanVar()
        self.upda_button = tk.Button(upda_frame,
                                     text=_('Upgrade'))
        self.upda_button.place(anchor=tk.CENTER, relx=0.5, rely=0.5)
        #self.upda_button.config(state='enable')
            
        text_frame.pack(side=tk.LEFT, anchor=tk.W)
        upda_frame.pack(side=tk.LEFT, anchor=tk.CENTER)

        # self.pack()

    # return Package, Filename, Install, UpdateRequest
    def get_request(self):
        return self.update_req.get()
"""